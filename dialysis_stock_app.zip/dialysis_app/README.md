# 💉 Dialysis Stock & Supplier Manager

आपका अपना **Dialysis Inventory + Supplier + Payment** मैनेजमेंट वेब ऐप।

## फीचर्स

- ✅ Stock In / Stock Out
- ✅ Current Stock + Low Stock Alert
- ✅ Supplier Management
- ✅ Purchase Bills
- ✅ Payment Tracking (बकाया कितना है)
- ✅ Items खुद ऐड कर सकते हो
- ✅ Reports
- ✅ मोबाइल + कंप्यूटर दोनों पर चलता है
- ✅ क्लाउड पर होस्ट कर सकते हो (फ्री)

---

## तरीका 1: लोकल कंप्यूटर पर चलाना (टेस्ट के लिए)

1. Python इंस्टॉल होना चाहिए (https://python.org)
2. इस फोल्डर में जाकर टर्मिनल खोलें
3. ये कमांड चलाएं:

```bash
pip install -r requirements.txt
streamlit run app.py
```

4. ब्राउज़र में अपने आप खुल जाएगा।

---

## तरीका 2: क्लाउड पर डालना (सबसे अच्छा - कहीं से भी खोल सकोगे)

### Streamlit Community Cloud पर फ्री होस्टिंग:

1. GitHub अकाउंट बनाओ (अगर नहीं है)
2. नया Repository बनाओ (उदाहरण: `dialysis-stock-app`)
3. इस पूरे फोल्डर की फाइलें (`app.py` और `requirements.txt`) अपलोड करो
4. https://share.streamlit.io पर जाओ और GitHub से लॉगिन करो
5. "New app" पर क्लिक करो
6. अपना repository चुनो → `app.py` सेलेक्ट करो → Deploy

**हो गया!** अब आपको एक लिंक मिलेगा जैसे:
`https://yourname-dialysis-stock-app.streamlit.app`

इस लिंक को मोबाइल या किसी भी कंप्यूटर से खोल सकते हो।

---

## डिफ़ॉल्ट आइटम जो पहले से हैं:

- Dialyzer
- Blood Tubing
- NS (Normal Saline)
- Heparin
- Fistula Needle
- CAPD Fluid
- AV Fistula Needle
- Dialysis Concentrate
- Gloves
- Syringe 10ml

आप **Items Master** से और आइटम ऐड कर सकते हो।

---

## नोट

- डेटा SQLite फाइल में सेव होता है (`dialysis_stock.db`)
- क्लाउड पर डिप्लॉय करने के बाद डेटा परसिस्टेंट रहेगा (Streamlit Cloud पर)
- अगर बहुत बड़ा डेटा हो तो बाद में PostgreSQL/MySQL भी लगा सकते हैं

---

बनाया गया: Grok द्वारा आपके लिए
